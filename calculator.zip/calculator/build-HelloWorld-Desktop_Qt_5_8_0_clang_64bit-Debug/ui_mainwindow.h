/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *label_result;
    QPushButton *btn_equal;
    QPushButton *btn_7;
    QPushButton *btn_8;
    QPushButton *btn_9;
    QPushButton *btn_0;
    QPushButton *btn_6;
    QPushButton *btn_2;
    QPushButton *btn_3;
    QPushButton *btn_4;
    QPushButton *btn_5;
    QPushButton *btn_1;
    QPushButton *btn_dot;
    QPushButton *btn_pre;
    QPushButton *btn_add;
    QPushButton *btn_sub;
    QPushButton *btn_mult;
    QPushButton *btn_division;
    QPushButton *btn_yu;
    QPushButton *btn_kuo;
    QPushButton *btn_c;
    QLabel *label_formula;
    QPushButton *btn_back;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(400, 456);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        label_result = new QLabel(centralWidget);
        label_result->setObjectName(QStringLiteral("label_result"));
        label_result->setEnabled(true);
        label_result->setGeometry(QRect(280, 90, 100, 16));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(label_result->sizePolicy().hasHeightForWidth());
        label_result->setSizePolicy(sizePolicy);
        label_result->setLayoutDirection(Qt::RightToLeft);
        label_result->setScaledContents(true);
        label_result->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        btn_equal = new QPushButton(centralWidget);
        btn_equal->setObjectName(QStringLiteral("btn_equal"));
        btn_equal->setGeometry(QRect(320, 330, 80, 70));
        QFont font;
        font.setPointSize(30);
        btn_equal->setFont(font);
        btn_7 = new QPushButton(centralWidget);
        btn_7->setObjectName(QStringLiteral("btn_7"));
        btn_7->setGeometry(QRect(80, 120, 80, 70));
        btn_7->setFont(font);
        btn_8 = new QPushButton(centralWidget);
        btn_8->setObjectName(QStringLiteral("btn_8"));
        btn_8->setGeometry(QRect(160, 120, 80, 70));
        btn_8->setFont(font);
        btn_9 = new QPushButton(centralWidget);
        btn_9->setObjectName(QStringLiteral("btn_9"));
        btn_9->setGeometry(QRect(240, 120, 80, 70));
        btn_9->setFont(font);
        btn_0 = new QPushButton(centralWidget);
        btn_0->setObjectName(QStringLiteral("btn_0"));
        btn_0->setGeometry(QRect(160, 330, 80, 70));
        btn_0->setFont(font);
        btn_6 = new QPushButton(centralWidget);
        btn_6->setObjectName(QStringLiteral("btn_6"));
        btn_6->setGeometry(QRect(240, 190, 80, 70));
        btn_6->setFont(font);
        btn_2 = new QPushButton(centralWidget);
        btn_2->setObjectName(QStringLiteral("btn_2"));
        btn_2->setGeometry(QRect(160, 260, 80, 70));
        btn_2->setFont(font);
        btn_3 = new QPushButton(centralWidget);
        btn_3->setObjectName(QStringLiteral("btn_3"));
        btn_3->setGeometry(QRect(240, 260, 80, 70));
        btn_3->setFont(font);
        btn_4 = new QPushButton(centralWidget);
        btn_4->setObjectName(QStringLiteral("btn_4"));
        btn_4->setGeometry(QRect(80, 190, 80, 70));
        btn_4->setFont(font);
        btn_5 = new QPushButton(centralWidget);
        btn_5->setObjectName(QStringLiteral("btn_5"));
        btn_5->setGeometry(QRect(160, 190, 80, 70));
        btn_5->setFont(font);
        btn_1 = new QPushButton(centralWidget);
        btn_1->setObjectName(QStringLiteral("btn_1"));
        btn_1->setGeometry(QRect(80, 260, 80, 70));
        btn_1->setFont(font);
        btn_dot = new QPushButton(centralWidget);
        btn_dot->setObjectName(QStringLiteral("btn_dot"));
        btn_dot->setGeometry(QRect(80, 330, 80, 70));
        btn_dot->setFont(font);
        btn_pre = new QPushButton(centralWidget);
        btn_pre->setObjectName(QStringLiteral("btn_pre"));
        btn_pre->setGeometry(QRect(240, 330, 80, 70));
        btn_pre->setFont(font);
        btn_add = new QPushButton(centralWidget);
        btn_add->setObjectName(QStringLiteral("btn_add"));
        btn_add->setGeometry(QRect(320, 260, 80, 70));
        btn_add->setFont(font);
        btn_sub = new QPushButton(centralWidget);
        btn_sub->setObjectName(QStringLiteral("btn_sub"));
        btn_sub->setGeometry(QRect(320, 190, 80, 70));
        btn_sub->setFont(font);
        btn_mult = new QPushButton(centralWidget);
        btn_mult->setObjectName(QStringLiteral("btn_mult"));
        btn_mult->setGeometry(QRect(320, 120, 80, 70));
        btn_mult->setFont(font);
        btn_division = new QPushButton(centralWidget);
        btn_division->setObjectName(QStringLiteral("btn_division"));
        btn_division->setGeometry(QRect(0, 190, 80, 70));
        btn_division->setFont(font);
        btn_yu = new QPushButton(centralWidget);
        btn_yu->setObjectName(QStringLiteral("btn_yu"));
        btn_yu->setGeometry(QRect(0, 260, 80, 70));
        btn_yu->setFont(font);
        btn_kuo = new QPushButton(centralWidget);
        btn_kuo->setObjectName(QStringLiteral("btn_kuo"));
        btn_kuo->setGeometry(QRect(0, 330, 80, 70));
        btn_kuo->setFont(font);
        btn_c = new QPushButton(centralWidget);
        btn_c->setObjectName(QStringLiteral("btn_c"));
        btn_c->setGeometry(QRect(0, 120, 80, 70));
        btn_c->setFont(font);
        label_formula = new QLabel(centralWidget);
        label_formula->setObjectName(QStringLiteral("label_formula"));
        label_formula->setGeometry(QRect(10, 10, 380, 70));
        label_formula->setTextFormat(Qt::AutoText);
        label_formula->setScaledContents(true);
        label_formula->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_formula->setWordWrap(false);
        label_formula->setTextInteractionFlags(Qt::NoTextInteraction);
        btn_back = new QPushButton(centralWidget);
        btn_back->setObjectName(QStringLiteral("btn_back"));
        btn_back->setGeometry(QRect(0, 60, 80, 70));
        btn_back->setFont(font);
        MainWindow->setCentralWidget(centralWidget);
        btn_equal->raise();
        btn_7->raise();
        label_result->raise();
        btn_8->raise();
        btn_9->raise();
        btn_0->raise();
        btn_6->raise();
        btn_2->raise();
        btn_3->raise();
        btn_4->raise();
        btn_5->raise();
        btn_1->raise();
        btn_dot->raise();
        btn_pre->raise();
        btn_add->raise();
        btn_sub->raise();
        btn_mult->raise();
        btn_division->raise();
        btn_yu->raise();
        btn_kuo->raise();
        btn_c->raise();
        label_formula->raise();
        btn_back->raise();
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 400, 22));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        btn_equal->setText(QApplication::translate("MainWindow", "=", Q_NULLPTR));
        btn_equal->setShortcut(QApplication::translate("MainWindow", "Ctrl+S", Q_NULLPTR));
        btn_7->setText(QApplication::translate("MainWindow", "7", Q_NULLPTR));
        btn_8->setText(QApplication::translate("MainWindow", "8", Q_NULLPTR));
        btn_9->setText(QApplication::translate("MainWindow", "9", Q_NULLPTR));
        btn_0->setText(QApplication::translate("MainWindow", "0", Q_NULLPTR));
        btn_6->setText(QApplication::translate("MainWindow", "6", Q_NULLPTR));
        btn_2->setText(QApplication::translate("MainWindow", "2", Q_NULLPTR));
        btn_3->setText(QApplication::translate("MainWindow", "3", Q_NULLPTR));
        btn_4->setText(QApplication::translate("MainWindow", "4", Q_NULLPTR));
        btn_5->setText(QApplication::translate("MainWindow", "5", Q_NULLPTR));
        btn_1->setText(QApplication::translate("MainWindow", "1", Q_NULLPTR));
        btn_dot->setText(QApplication::translate("MainWindow", ".", Q_NULLPTR));
        btn_pre->setText(QApplication::translate("MainWindow", "+/-", Q_NULLPTR));
        btn_add->setText(QApplication::translate("MainWindow", "+", Q_NULLPTR));
        btn_sub->setText(QApplication::translate("MainWindow", "-", Q_NULLPTR));
        btn_mult->setText(QApplication::translate("MainWindow", "x", Q_NULLPTR));
        btn_division->setText(QApplication::translate("MainWindow", "\303\267", Q_NULLPTR));
        btn_yu->setText(QApplication::translate("MainWindow", "%", Q_NULLPTR));
        btn_kuo->setText(QApplication::translate("MainWindow", "()", Q_NULLPTR));
        btn_c->setText(QApplication::translate("MainWindow", "C", Q_NULLPTR));
        label_formula->setText(QString());
        btn_back->setText(QApplication::translate("MainWindow", "<-", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
