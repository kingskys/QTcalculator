/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../HelloWorld/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[32];
    char stringdata0[507];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 8), // "initData"
QT_MOC_LITERAL(2, 20, 0), // ""
QT_MOC_LITERAL(3, 21, 9), // "calculate"
QT_MOC_LITERAL(4, 31, 10), // "updateView"
QT_MOC_LITERAL(5, 42, 18), // "updateFormulaLabel"
QT_MOC_LITERAL(6, 61, 20), // "updateMidResultLabel"
QT_MOC_LITERAL(7, 82, 10), // "isPreValid"
QT_MOC_LITERAL(8, 93, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(9, 115, 16), // "on_btn_c_clicked"
QT_MOC_LITERAL(10, 132, 12), // "add_left_kuo"
QT_MOC_LITERAL(11, 145, 13), // "add_right_kuo"
QT_MOC_LITERAL(12, 159, 18), // "on_btn_kuo_clicked"
QT_MOC_LITERAL(13, 178, 19), // "on_btn_back_clicked"
QT_MOC_LITERAL(14, 198, 11), // "addNumValue"
QT_MOC_LITERAL(15, 210, 4), // "text"
QT_MOC_LITERAL(16, 215, 16), // "on_btn_7_clicked"
QT_MOC_LITERAL(17, 232, 16), // "on_btn_8_clicked"
QT_MOC_LITERAL(18, 249, 16), // "on_btn_9_clicked"
QT_MOC_LITERAL(19, 266, 16), // "on_btn_4_clicked"
QT_MOC_LITERAL(20, 283, 16), // "on_btn_5_clicked"
QT_MOC_LITERAL(21, 300, 16), // "on_btn_6_clicked"
QT_MOC_LITERAL(22, 317, 16), // "on_btn_1_clicked"
QT_MOC_LITERAL(23, 334, 16), // "on_btn_2_clicked"
QT_MOC_LITERAL(24, 351, 16), // "on_btn_3_clicked"
QT_MOC_LITERAL(25, 368, 16), // "on_btn_0_clicked"
QT_MOC_LITERAL(26, 385, 18), // "on_btn_dot_clicked"
QT_MOC_LITERAL(27, 404, 18), // "on_btn_add_clicked"
QT_MOC_LITERAL(28, 423, 18), // "on_btn_sub_clicked"
QT_MOC_LITERAL(29, 442, 19), // "on_btn_mult_clicked"
QT_MOC_LITERAL(30, 462, 23), // "on_btn_division_clicked"
QT_MOC_LITERAL(31, 486, 20) // "on_btn_equal_clicked"

    },
    "MainWindow\0initData\0\0calculate\0"
    "updateView\0updateFormulaLabel\0"
    "updateMidResultLabel\0isPreValid\0"
    "on_pushButton_clicked\0on_btn_c_clicked\0"
    "add_left_kuo\0add_right_kuo\0"
    "on_btn_kuo_clicked\0on_btn_back_clicked\0"
    "addNumValue\0text\0on_btn_7_clicked\0"
    "on_btn_8_clicked\0on_btn_9_clicked\0"
    "on_btn_4_clicked\0on_btn_5_clicked\0"
    "on_btn_6_clicked\0on_btn_1_clicked\0"
    "on_btn_2_clicked\0on_btn_3_clicked\0"
    "on_btn_0_clicked\0on_btn_dot_clicked\0"
    "on_btn_add_clicked\0on_btn_sub_clicked\0"
    "on_btn_mult_clicked\0on_btn_division_clicked\0"
    "on_btn_equal_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      29,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  159,    2, 0x08 /* Private */,
       3,    0,  160,    2, 0x08 /* Private */,
       4,    0,  161,    2, 0x08 /* Private */,
       5,    0,  162,    2, 0x08 /* Private */,
       6,    0,  163,    2, 0x08 /* Private */,
       7,    0,  164,    2, 0x08 /* Private */,
       8,    0,  165,    2, 0x08 /* Private */,
       9,    0,  166,    2, 0x08 /* Private */,
      10,    0,  167,    2, 0x08 /* Private */,
      11,    0,  168,    2, 0x08 /* Private */,
      12,    0,  169,    2, 0x08 /* Private */,
      13,    0,  170,    2, 0x08 /* Private */,
      14,    1,  171,    2, 0x08 /* Private */,
      16,    0,  174,    2, 0x08 /* Private */,
      17,    0,  175,    2, 0x08 /* Private */,
      18,    0,  176,    2, 0x08 /* Private */,
      19,    0,  177,    2, 0x08 /* Private */,
      20,    0,  178,    2, 0x08 /* Private */,
      21,    0,  179,    2, 0x08 /* Private */,
      22,    0,  180,    2, 0x08 /* Private */,
      23,    0,  181,    2, 0x08 /* Private */,
      24,    0,  182,    2, 0x08 /* Private */,
      25,    0,  183,    2, 0x08 /* Private */,
      26,    0,  184,    2, 0x08 /* Private */,
      27,    0,  185,    2, 0x08 /* Private */,
      28,    0,  186,    2, 0x08 /* Private */,
      29,    0,  187,    2, 0x08 /* Private */,
      30,    0,  188,    2, 0x08 /* Private */,
      31,    0,  189,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->initData(); break;
        case 1: _t->calculate(); break;
        case 2: _t->updateView(); break;
        case 3: _t->updateFormulaLabel(); break;
        case 4: _t->updateMidResultLabel(); break;
        case 5: { bool _r = _t->isPreValid();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 6: _t->on_pushButton_clicked(); break;
        case 7: _t->on_btn_c_clicked(); break;
        case 8: { bool _r = _t->add_left_kuo();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 9: { bool _r = _t->add_right_kuo();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 10: _t->on_btn_kuo_clicked(); break;
        case 11: _t->on_btn_back_clicked(); break;
        case 12: _t->addNumValue((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 13: _t->on_btn_7_clicked(); break;
        case 14: _t->on_btn_8_clicked(); break;
        case 15: _t->on_btn_9_clicked(); break;
        case 16: _t->on_btn_4_clicked(); break;
        case 17: _t->on_btn_5_clicked(); break;
        case 18: _t->on_btn_6_clicked(); break;
        case 19: _t->on_btn_1_clicked(); break;
        case 20: _t->on_btn_2_clicked(); break;
        case 21: _t->on_btn_3_clicked(); break;
        case 22: _t->on_btn_0_clicked(); break;
        case 23: _t->on_btn_dot_clicked(); break;
        case 24: _t->on_btn_add_clicked(); break;
        case 25: _t->on_btn_sub_clicked(); break;
        case 26: _t->on_btn_mult_clicked(); break;
        case 27: _t->on_btn_division_clicked(); break;
        case 28: _t->on_btn_equal_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 29)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 29;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 29)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 29;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
