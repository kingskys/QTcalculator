#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <iostream>

using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->initData();
}

MainWindow::~MainWindow()
{
    if (this->expMode) {
        delete this->expMode;
        this->expMode = nullptr;
    }

    delete ui;
}

void MainWindow::initData() {
    this->formulaText = "";
    this->midResultText = "";

    this->expMode = new ExpMode();
}

void MainWindow::calculate() {
    this->expMode->parse(this->formulaText);
}

void MainWindow::updateView() {
    this->updateFormulaLabel();
    this->updateMidResultLabel();
}

void MainWindow::updateFormulaLabel() {
    ui->label_formula->setText(this->formulaText);
}

void MainWindow::updateMidResultLabel() {
    QString msg;
    if (this->expMode->isSuccess()) {
        msg = this->expMode->getResult();
    }
    else {
        msg = this->expMode->getErrMsg();
    }

    ui->label_result->setText(msg);

}

// 之前的字符是否合法
bool MainWindow::isPreValid() {
    this->expMode->parse(this->formulaText);
    if (this->expMode->haveInvalidCode()) {
        return false;
    }

    return true;
}

void MainWindow::on_pushButton_clicked()
{

}

void MainWindow::on_btn_c_clicked()
{
    this->initData();
    this->updateView();

}

bool MainWindow::add_left_kuo() {
    QString lastCode = this->expMode->getLastCode();
    if (lastCode == "(" || lastCode == "+" || lastCode == "-" || lastCode == "x" || lastCode == "÷") {
        this->formulaText.append("(");
        this->expMode->resetData();
        this->updateView();
    }
    else if ((lastCode >= "0" && lastCode <= "9") || lastCode == ")" || lastCode == ".") {
        if (this->expMode->getLeftBracket() > this->expMode->getRightBracket()) {
            this->formulaText.append(")");
            this->calculate();
            this->updateView();
        }
        else {
            this->formulaText.append("x(");
            this->expMode->resetData();
            this->updateView();
        }
    }

    return true;
}

bool MainWindow::add_right_kuo() {
    return true;
}

void MainWindow::on_btn_kuo_clicked()
{
    int nLen = this->formulaText.length();
    if (nLen > 0) {
        if (this->isPreValid()) {
            if (!this->add_left_kuo()) {
                this->add_right_kuo();
            }
        }
        else {
            this->updateView();
        }
    }
    else {
        this->formulaText.append("(");
        this->expMode->resetData();
        this->updateView();
    }

}

void MainWindow::on_btn_back_clicked()
{
    if (this->formulaText.length() > 0) {
        this->formulaText.remove(this->formulaText.length()-1, 1);
        this->calculate();
        this->updateView();
    }
}


void MainWindow::addNumValue(QString text) {
    int nLen = this->formulaText.length();
    if (nLen > 0) {
        if (this->isPreValid()) {
            QString lastCode = this->expMode->getLastCode();
            if (nLen == 1 && lastCode == "0") {
                this->formulaText.replace(0, 1, text);
                this->calculate();
                this->updateView();
                return;
            }

            if (lastCode == ")") {
                this->formulaText.append("x");
            }

            this->formulaText.append(text);
            this->calculate();
            this->updateView();
        }
        else {
            this->updateView();
        }
    }
    else {
        this->formulaText.append(text);
        this->calculate();
        this->updateView();
    }
}

void MainWindow::on_btn_7_clicked()
{
    this->addNumValue("7");
}

void MainWindow::on_btn_8_clicked()
{
    this->addNumValue("8");
}

void MainWindow::on_btn_9_clicked()
{
    this->addNumValue("9");
}

void MainWindow::on_btn_4_clicked()
{
    this->addNumValue("4");
}

void MainWindow::on_btn_5_clicked()
{
    this->addNumValue("5");
}

void MainWindow::on_btn_6_clicked()
{
    this->addNumValue("6");
}

void MainWindow::on_btn_1_clicked()
{
    this->addNumValue("1");
}

void MainWindow::on_btn_2_clicked()
{
    this->addNumValue("2");
}

void MainWindow::on_btn_3_clicked()
{
    this->addNumValue("3");
}

void MainWindow::on_btn_0_clicked()
{
    this->addNumValue("0");
}

void MainWindow::on_btn_dot_clicked()
{
    QString text = this->formulaText;
    int nLen = text.length();
    if (nLen > 0) {
        if (this->isPreValid()) {
            if (this->expMode->match(text, "\\d+\\.\\d*$")) { // 数字已经有1个点了
                return;
            }
            else if (this->expMode->match(text, "\\d+$")) {
                this->formulaText.append(".");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(text, "[(x÷+-]$")) {
                this->formulaText.append("0.");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(text, "\\)$")) {
                this->formulaText.append("x0.");
                this->calculate();
                this->updateView();
            }

        }
        else {
            this->updateView();
        }
    }
    else {
        this->formulaText.append("0.");
    }
}

void MainWindow::on_btn_add_clicked()
{
    int nLen = this->formulaText.length();

    if (nLen > 0) {
        if (this->isPreValid()) {
            if (this->expMode->match(this->formulaText, "\\([+-]$")) {
                this->formulaText.replace(nLen-1, 1, "+");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "[x÷+-]$")) {
                this->formulaText.replace(nLen-1, 1, "+");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "[0-9]+\\.?[0-9]*$")) {
                this->formulaText.append("+");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "\\)$")) {
                this->formulaText.append("+");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "\\($")) {
                this->formulaText.append("+");
                this->calculate();
                this->updateView();
            }
        }
    }

}

void MainWindow::on_btn_sub_clicked()
{
    int nLen = this->formulaText.length();

    if (nLen > 0) {
        if (this->isPreValid()) {
            if (this->expMode->match(this->formulaText, "\\([+-]$")) {
                this->formulaText.replace(nLen-1, 1, "-");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "[x÷+-]$")) {
                this->formulaText.replace(nLen-1, 1, "-");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "\\d+\\.?\\d*$")) {
                this->formulaText.append("-");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "\\)$")) {
                this->formulaText.append("-");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "\\($")) {
                this->formulaText.append("-");
                this->calculate();
                this->updateView();
            }
        }
    }

}

void MainWindow::on_btn_mult_clicked()
{
    int nLen = this->formulaText.length();

    if (nLen > 0) {
        if (this->isPreValid()) {
            if (this->expMode->match(this->formulaText, "\\([+-]$")) {
                this->formulaText.remove(nLen-1, 1);
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "[x÷+-]$")) {
                this->formulaText.replace(nLen-1, 1, "x");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "\\d+\\.?\\d*$")) {
                this->formulaText.append("x");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "\\)$")) {
                this->formulaText.append("x");
                this->calculate();
                this->updateView();
            }
        }
    }
}

void MainWindow::on_btn_division_clicked()
{
    int nLen = this->formulaText.length();

    if (nLen > 0) {
        if (this->isPreValid()) {
            if (this->expMode->match(this->formulaText, "\\([+-]$")) {
                this->formulaText.remove(nLen-1, 1);
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "[x÷+-]$")) {
                this->formulaText.replace(nLen-1, 1, "÷");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "\\d+\\.?\\d*$")) {
                this->formulaText.append("÷");
                this->calculate();
                this->updateView();
            }
            else if (this->expMode->match(this->formulaText, "\\)$")) {
                this->formulaText.append("÷");
                this->calculate();
                this->updateView();
            }
        }
    }
}

void MainWindow::on_btn_equal_clicked()
{
    QString text = "7x8x(5+6)+2-(-2)x7x(-4)-2";
    this->expMode->parse(text);
}
