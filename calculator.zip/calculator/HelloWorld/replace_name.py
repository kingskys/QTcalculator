import sys
import os, os.path


def renameFileName(dir, filename, fromstr, tostr):
	resultname = filename.replace(fromstr, tostr, 1);
	os.rename(os.path.join(dir, filename), os.path.join(dir, resultname));
	print "replace:" + filename + "->" + resultname

def renameFilesName(dir, fromstr, tostr):
	for x in os.listdir(dir):
		if x == ".DS_Store":
			continue;
		m_path = os.path.join(dir, x)
		if os.path.isdir(m_path):			
			renameFiles(m_path, fromstr, tostr);
		else:
			renameFileName(dir, x, fromstr, tostr);

def main():
	renameFilesName(work_dir, from_string, to_string)



if __name__ == '__main__':
	if len(sys.argv) != 4 :
		print "argv len must be 4"

	from_string = sys.argv[2]
	to_string = sys.argv[3]
	work_dir = sys.argv[1] # will remove file dir

	main()


