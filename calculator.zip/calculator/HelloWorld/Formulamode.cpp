#include "Formulamode.h"

// 含有非法字符
bool haveInvalidCode(QString& text) {
    int nLen = text.length();
    for (int i = 0; i < nLen; i++) {
        QString chr = text.mid(i, 1);
        if (chr >= "0" && chr <= "9") {
            continue;
        }

        if ((chr == "+") || (chr == "-") || (chr == "x") || (chr == "÷") || (chr == "(") || (chr == ")")) {
            continue;
        }

        if (chr == ".") {
            continue;
        }

        return true;
    }

    return false;
}

bool checkLastCode(QString chr) {
    if (chr >= "0" && chr <= "9") {
        return true;
    }

    if (chr == ".") {
        return true;
    }

    if (chr == ")") {
        return true;
    }

    return false;
}

FormulaMode::FormulaMode() {

}

void FormulaMode::initData() {
    this->bErr = false;
    this->bInvalidCode = false;
    this->errMsg = "";
    this->text = "";
    this->result = "";
    this->lastCode = "";
    this->nLeftBracket = 0;
    this->nRightBracket = 0;
    this->nSymbol = 0;
}

void FormulaMode::getInfo() {
    this->nLeftBracket = 0;
    this->nRightBracket = 0;
    this->nSymbol = 0;

    QString chr;
    for (int i = this->text.length()-1; i >= 0; i--) {
        chr = this->text.at(i);
        if (chr == "(") {
            this->nLeftBracket++;
            this->nSymbol++;
        }
        else if (chr == ")") {
            this->nRightBracket++;
            this->nSymbol++;
        }
        else if (chr == "x" || chr == "÷" || chr == "+" || chr == "-") {
            this->nSymbol++;
        }
    }
}

bool FormulaMode::isSuccess() {
    return !this->bErr;
}

bool FormulaMode::isInvalidCode() {
    return this->bInvalidCode;
}


QString FormulaMode::getErrMsg() {
    return this->errMsg;
}

QString FormulaMode::getResult() {
    return this->result;
}

QString FormulaMode::getLastCode() {
    return this->lastCode;
}

// 左括号数量
int FormulaMode::getLeftBracketCount() {
    return this->nLeftBracket;
}

// 右括号数量
int FormulaMode::getRightBracketCount() {
    return this->nRightBracket;
}

// 符号数量
int FormulaMode::getSymbolCount() {
    return this->nSymbol;
}

void FormulaMode::parse(QString text) {
    qDebug("公式：%s", qPrintable(text));
    this->initData();
    this->text = text;

    if (this->text.length() > 0) {
        this->bInvalidCode = haveInvalidCode(this->text);
        if (this->bInvalidCode) {
            this->bErr = true;
            this->errMsg = "含有非法字符";
        }
        else {
            this->lastCode = this->text.right(1);
            if (checkLastCode(this->lastCode)) {
                this->result = this->calculateResult(this->text);
            }
            else {
                this->bErr = true;
            }
        }
    }
}



QString FormulaMode::calculate(QString text) {
    qDebug("计算：%s", qPrintable(text));

    int nLen = text.length();

    int index = -1;
    QString symbol = "";
    QString chr;
    for (int i = 0; i < nLen; i++) {
        chr = text.mid(i, 1);
        if (chr == "x" || chr == "÷" || chr == "+" || chr == "-") {
            if (i == nLen - 1) {
                this->bErr = true;
                return "";
            }

            if (i == 0 && (chr == "+" || chr == "-")) {
                continue;
            }

            index = i;
            symbol = chr;
            break;
        }
    }

    if (index > 0) {
        QString text1 = text.mid(0, index);
        QString text2 = text.mid(index+1);
        float value1 = text1.toFloat();
        float value2 = text2.toFloat();
        if (symbol == "+") {
            return QString("%1").arg(value1 + value2);
        }
        else if (symbol == "-") {
            return QString("%1").arg(value1 - value2);
        }
        else if (symbol == "x") {
            return QString("%1").arg(value1 * value2);
        }
        else if (symbol == "÷") {
            if (value2 == 0) {
                this->bErr = true;
                this->errMsg = "除数不能为0";
                return "0";
            }

            return QString("%1").arg(value1 / value2);
        }
    }
    else {
        return text;
    }

    return "";
}

QString FormulaMode::calculateResult(QString text) {
    if (this->bErr) {
        return "0";
    }

    qDebug("＝＝＝子公式：%s", qPrintable(text));

    if (text.length() == 0) {
        this->bErr = true;
        return "0";
    }

    int indexL = text.indexOf("(");
    int indexR = text.lastIndexOf(")");

    if (indexL >= 0) {
        if (indexR < 0) {
            indexR = text.length()-1;
        }

        if (indexR <= indexL+1) {
            this->bErr = true;
            return "0";
        }

        // 找出右边对应的括号
        int nLeftBracket = 1;
        int nRightBracket = 0;
        for (int i = indexL+1; i < indexR; i++) {
            QString chr = text.mid(i, 1);
            if (chr == "(") {
                nLeftBracket++;
            } else if (chr == ")") {
                nRightBracket++;
            }

            if (nLeftBracket == nRightBracket) {
                indexR = i;
                break;
            }
        }

        int nLength = indexR - indexL + 1;

        QString tempString = text.mid(indexL+1, nLength-2);
        QString tempResult = this->calculateResult(tempString);
        if (this->bErr) {
            return "0";
        }

        text.remove(indexL, nLength);

        text.insert(indexL, tempResult);

        return this->calculateResult(text);

    }
    else if (indexR >= 0) {
        this->bErr = true;
        return "0";
    }

    // 没括号情况
    int nLen = text.length();
    indexL = -1;
    indexR = -1;
    bool start = false;
    for (int i = 0; i < nLen; i++) {
        QString chr = text.mid(i, 1);
        if (!start) {
            if (chr == "+" || chr == "-") {
                indexL = i;
            }
            else if (chr == "x" || chr == "÷") {
                start = true;
            }
        }
        else {
            if (chr == "x" || chr == "÷" || chr == "+" || chr == "-") {
                indexR = i;
                break;
            }
        }

    }

    // 没有 x或÷
    if (!start) {
        indexL = -1;
        indexR = -1;
        for (int i = 1; i < nLen; i++) {
            QString chr = text.mid(i, 1);
            if (!start) {
                if (chr == "+" || chr == "-") {
                    start = true;
                }
            }
            else {
                if (chr == "+" || chr == "-") {
                    indexR = i;
                    break;
                }
            }

        }

    }

    qDebug("indexL:%d, indexR:%d", indexL, indexR);

    if (start) { // 有算数符号
        if (indexR > 0 || indexL > 0) { // 还有
            if (indexR < 0) {
                indexR = nLen;
            }
            indexL += 1;
            int nLength = indexR - indexL;

            qDebug("len:%d", nLength);
            QString tempString = text.mid(indexL, nLength);
            QString tempResult = this->calculate(tempString);
            if (this->bErr) {
                return "0";
            }

            text.remove(indexL, nLength);

            text.insert(indexL, tempResult);

            return this->calculateResult(text);
        }
        else { // 只有1个算数符号
            return this->calculate(text);
        }
    }
    else { // 没有算数符号
        return text;
    }


}
