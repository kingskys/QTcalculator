#include "ExpMode.h"
#include "qregexp.h"

ExpMode::ExpMode() {

}

bool checkTheLastCode(QString chr) {
    if (chr >= "0" && chr <= "9") {
        return true;
    }

    if (chr == ".") {
        return true;
    }

    if (chr == ")") {
        return true;
    }

    return false;
}

void ExpMode::resetData() {
    this->bErr = false;
    this->text.clear();
    this->result.clear();
    this->sErrMsg.clear();
    this->bIllegalCode = false;
    this->lastCode.clear();

    this->nLeftBracket = 0;
    this->nRighttBracket = 0;
}

void ExpMode::parse(QString text) {
    this->resetData();
    qDebug("++++++++++++++++++++++++++++++parse:%s", qPrintable(text));

    this->text = text;
    if (this->text.length() > 0) {
        this->bIllegalCode = this->checkIllegalCode();
        if (this->bIllegalCode) {
            this->bErr = true;
            this->sErrMsg = "含有非法字符";
        }
        else {
            this->lastCode = this->text.right(1);
            if (checkTheLastCode(this->lastCode)) {
                this->result = this->calculateResult(this->text);
                qDebug("最终结果:%s", qPrintable(this->result));
            }
            else {
                this->bErr = true;
            }
        }
    }
    else {
        this->bErr = true;
    }

}

bool ExpMode::isSuccess() {
    return !this->bErr;
}

QString ExpMode::getErrMsg() {
    return this->sErrMsg;
}

QString ExpMode::getResult() {
    return this->result;
}

QString ExpMode::getLastCode() {
    return this->lastCode;
}

bool ExpMode::haveInvalidCode() {
    return this->bIllegalCode;
}


bool ExpMode::checkIllegalCode() {
    foreach (QString chr, this->text) {
        if ((chr >= "0" && chr <= "9") || (chr == ".") ||
                (chr == "+") || (chr == "-") || (chr == "x") || (chr == "÷")) {

        }
        else if (chr == "(") {
            this->nLeftBracket++;
        }
        else if (chr == ")") {
            this->nRighttBracket++;
        }
        else {
            return true;
        }
    }

    if (this->match(this->text, "\\d+\\.\\d*\\.")) {
        return true;
    }

    return false;
}

int ExpMode::getLeftBracket() {
    return this->nLeftBracket;
}

int ExpMode::getRightBracket() {
    return this->nRighttBracket;
}

bool ExpMode::match(QString text, QString pattern) {
    QRegExp re(pattern);
    int pos = text.indexOf(re);
    return (pos >= 0);
}

// 查找空括号
bool ExpMode::checkEmptyBracket(QString text) {
    QString pattern = "\\(\\)";
    QRegExp re(pattern);
    int pos = text.indexOf(re);
    qDebug("查找空括号 pos:%d", pos);

    return (pos >= 0);
}

QString ExpMode::calculateResult(QString text) {
    if (this->bErr) {
        return 0;
    }

    qDebug("计算解析公式：%s", qPrintable(text));

    if (text.length() == 0) {
        return this->returnInvalidResult();
    }

    int indexL = text.indexOf("(");
    int indexR = text.lastIndexOf(")");

    qDebug("indexL=%d, indexR=%d", indexL, indexR);

    if (indexL >= 0) {
        if (indexR < 0) {
            text.append(")");
            indexR = text.length()-1;
        }

        if (this->checkEmptyBracket(text)) {
            this->bErr = true;
            this->sErrMsg = "括号中不可以没值";
            return "0";
        }

        QString pattern = "\\(([^()]+)\\)";
        QRegExp re(pattern);
        int pos = text.indexOf(re);
        qDebug("查找带括号表达式 pos:%d", pos);
        if (pos >= 0) {
            QString exp = re.cap(0);
            qDebug("查找带括号表达式:%s", qPrintable(exp));
            qDebug("表达式:%s", qPrintable(re.cap(1)));

            int nLen = exp.length();
            QString tmpResult = this->calculate(re.cap(1));
            if (this->isSuccess()) {
                text.remove(pos, nLen);
                text.insert(pos, tmpResult);
                text.replace("+-", "-").replace("-+", "-").replace("++", "+").replace("--", "+");
                return this->calculateResult(text);
            }
            else {
                return "0";
            }
        }
        else {
            return this->returnInvalidResult();
        }

    }
    else if (indexR >= 0) {
        return this->returnInvalidResult();
    }

    return this->calculate(text);
}

QString ExpMode::calculate(QString text) {
    if (!this->isSuccess()) {
        return "0";
    }

    text.replace("+-", "-").replace("-+", "-").replace("++", "+").replace("--", "+");

    qDebug("公式：%s", qPrintable(text));

    QString outResult = "";
    if (this->calculateWithPattern(text, "(\\d+\\.?\\d*)([x÷])(\\-?\\d+\\.?\\d*)", outResult)) {
        return outResult;
    }
    else {
        outResult.clear();
        if (this->calculateWithPattern(text, "(\\d+\\.?\\d*)([+-])(\\-?\\d+\\.?\\d*)", outResult)) {
            return outResult;
        }
    }

    return text;
}

bool ExpMode::calculateWithPattern(QString text, QString pattern, QString& outResult) {
//    qDebug("pattern：%s", qPrintable(pattern));

    QRegExp re(pattern);
    int pos = text.indexOf(re);
    qDebug("pos:%d", pos);

    if (pos >= 0) {
        QString exp = re.cap(0);
        int nLen = exp.length();
        QString symbol = re.cap(2);
        qDebug("value1：%s, symbol:%s, value2：%s", qPrintable(re.cap(1)), qPrintable(symbol), qPrintable(re.cap(3)));
        float value1 = re.cap(1).toFloat();
        float value2 = re.cap(3).toFloat();
        QString tmpResult = this->calculateFormula(value1, value2, symbol);

        text.remove(pos, nLen);
        text.insert(pos, tmpResult);
        outResult.append(this->calculate(text));
        return true;
    }

    return false;
}

QString ExpMode::calculateFormula(float value1, float value2, QString symbol) {
    QString tmpResult = "";
    if (symbol == "+") {
        tmpResult = QString("%1").arg(value1 + value2);
    }
    else if (symbol == "-") {
        tmpResult = QString("%1").arg(value1 - value2);
    }
    else if (symbol == "x") {
        tmpResult = QString("%1").arg(value1 * value2);
    }
    else if (symbol == "÷") {
        if (value2 == 0) {
            this->bErr = true;
            this->sErrMsg = "0不能为除数";
            return "0";
        }

        tmpResult = QString("%1").arg(value1 / value2);
    }

    return tmpResult;
}

QString ExpMode::returnInvalidResult() {
    this->bErr = true;
    this->sErrMsg = "无效格式";
    return "0";
}
