#ifndef FORMULAMODE_H
#define FORMULAMODE_H

#include "qstring.h"

class FormulaMode
{
public:
    FormulaMode();

    void initData();

    void parse(QString text);

    bool isSuccess();

    bool isInvalidCode();

    QString getErrMsg();

    QString getResult();

    // 最后一个字符
    QString getLastCode();

    // 左括号数量
    int getLeftBracketCount();

    // 右括号数量
    int getRightBracketCount();

    // 符号数量
    int getSymbolCount();


private:


    void getInfo();

    QString calculate(QString text);

    QString calculateResult(QString text);

private:
    bool bErr;
    bool bInvalidCode;
    QString text;
    QString errMsg;
    QString result;
    QString lastCode;
    int nLeftBracket;
    int nRightBracket;
    int nSymbol;

};

#endif // FORMULAMODE_H
