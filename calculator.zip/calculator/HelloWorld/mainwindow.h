#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "ExpMode.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void initData();

    void calculate();

    void updateView();

    void updateFormulaLabel();

    void updateMidResultLabel();

    bool isPreValid();

    void on_pushButton_clicked();

    void on_btn_c_clicked();

    bool add_left_kuo();
    bool add_right_kuo();
    void on_btn_kuo_clicked();

    void on_btn_back_clicked();

    void addNumValue(QString text);

    void on_btn_7_clicked();

    void on_btn_8_clicked();

    void on_btn_9_clicked();

    void on_btn_4_clicked();

    void on_btn_5_clicked();

    void on_btn_6_clicked();

    void on_btn_1_clicked();

    void on_btn_2_clicked();

    void on_btn_3_clicked();

    void on_btn_0_clicked();

    void on_btn_dot_clicked();

    void on_btn_add_clicked();

    void on_btn_sub_clicked();

    void on_btn_mult_clicked();

    void on_btn_division_clicked();

    void on_btn_equal_clicked();

private:
    Ui::MainWindow *ui;

    QString formulaText;
    QString midResultText;

    ExpMode* expMode;

};

#endif // MAINWINDOW_H
