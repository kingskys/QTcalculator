#ifndef EXPMODE_H
#define EXPMODE_H

#include "qstring.h"

class ExpMode
{
public:
    ExpMode();

    void resetData();

    void parse(QString text);

    bool isSuccess();

    QString getErrMsg();

    bool haveInvalidCode();

    QString getResult();

    QString getLastCode();

    int getLeftBracket();

    int getRightBracket();

    bool match(QString text, QString pattern);

private:
    bool checkIllegalCode();

    QString calculateResult(QString text);

    QString calculate(QString text);

    bool calculateWithPattern(QString text, QString pattern, QString& outResult);

    QString calculateFormula(float value1, float value2, QString symbol);

    QString returnInvalidResult();

    // 查找空括号
    bool checkEmptyBracket(QString text);

private:
    QString text;
    QString result;
    bool bErr;
    QString sErrMsg;

    bool bIllegalCode;

    QString lastCode;

    int nLeftBracket;

    int nRighttBracket;

};

#endif // EXPMODE_H
